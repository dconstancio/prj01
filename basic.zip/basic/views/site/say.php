<?php
use yii\helpers\Html;
?>
<?= HTML::encode($message) ?>
