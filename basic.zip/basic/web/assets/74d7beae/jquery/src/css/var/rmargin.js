define(function() {
	return (/^margin/);
});
