<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=mydb',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
